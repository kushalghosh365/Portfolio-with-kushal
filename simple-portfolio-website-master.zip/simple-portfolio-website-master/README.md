## **Built With**

This project was built using the following technologies.

- HTML5
- CSS3
- JavaScript
- jQuery
- Bootstrap
- FontAwesome Icons
- Bootstrap Icons

## **Features**

- **📖 Single-Page Layout**

- **🎨 Styled with Bootstrap and Css**

- **📱 Fully Responsive**


